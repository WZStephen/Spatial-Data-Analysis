package cse512

object HotzoneUtils {

  def ST_Contains(queryRectangle: String, pointString: String ): Boolean = {
    val r = queryRectangle.split(",").map(cord => cord.toDouble)
    val index = pointString.split(",").map(cord => cord.toDouble)

    val minX = math.min(r(0), r(2))
    val maxX = math.max(r(0), r(2))
    val minY = math.min(r(1), r(3))
    val maxY = math.max(r(1), r(3))

    if (minX <= index(0)
      && index(0) <= maxX
      && minY <= index(1)
      && index(1) <= maxY)
      {
        true
      }
    else
      {
        false
      }
  }

}